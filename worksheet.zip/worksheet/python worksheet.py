#!/usr/bin/env python
# coding: utf-8

# ## 1
# C = %

# ## 2
# B = 0

# ## 3
# C = 24

# ## 4
# a = 2

# ## 5
# d = 6

# ## 6
# c = finally block will be excuted no matter if try block raises an error or not.

# ## 7
# A = it is used to raise an exception

# ## 8
# c = in defining a generator

# ## 9
# A , c are correct
# variable names should start with character (alphabets) , underscore

# ## 10
# A = yield
# b = raise

# ## 11

# In[ ]:


def fac(n):
    if n in (0,1):
        print(f"factorail of {n} is 1" )
    else:
        res = 1
        while (n>1):
            res = res * n
            n -= 1
    return res


# In[ ]:


n = int(input(f"enter only intigers"))
from math import factorial
factorial(n)


# ## 12

# In[ ]:


def prime(p):
    n,i= p,0
    l=[]
    while (n>1):
        if(p%n == 0):
            l.append(n)            
            i+= 1
        n -= 1
    if i == 1:
        print(f"{p} is prime number")
    else:
        print(f"{p} is composite number, {l}")


# ## 13

# In[ ]:


data = list(input("enter the sequnce to check palindrome or not "))
temp = data[::-1]
if data == temp:
    print(f"{data} is palindrome")
else :
    print(f"{data} is not palindrome")


# ## 14

# In[ ]:


def triangle(self=0):
    import urllib
    from PIL import Image
    urllib.request.urlretrieve('https://raw.githubusercontent.com/premasaireddy/image/main/triangle.png','trinagle.png')
    img = Image.open('trinagle.png')
    img.show()
    print(f"above image as refernce enter sides as per image")
    adj = int(input(f" Enter adjcent side of triangle "))
    opp = int(input(f" Enter opposite side of triangle "))
    hyp = int(input(f" Enter hypotenuse side of triangle "))
    side_of_triangle(adj,opp,hyp)
    
def side_of_triangle(adj= 0,opp=0,hyp = 0):
    import math
    adj,opp,hyp = math.pow(adj,2),math.pow(opp,2),math.pow(hyp,2)
    print(f"adjcent is {math.sqrt(abs(hyp - opp))}" if adj == 0 else (print(f" oppsite is {math.sqrt(abs(hyp - adj))}")) if opp ==0 else print(f"hypotenuse is {math.sqrt(adj+opp)}"))


# ## 15

# In[ ]:


data= input('enter the data')
a = []
print(f" following are character and its count")
for i in data:
    if i not in a:
        print(f"{i}  {data.count(i)} ")
        a.append(i)  

